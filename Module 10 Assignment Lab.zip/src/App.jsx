import { useState } from "react";
import { Routes, Route } from "react-router";
import Navbar from "./components/Navbar";
import BlogPostsPage from "./pages/BlogPostsPage";
import IndividualPostPage from "./pages/IndividualPostPage";
import ContactPage from "./pages/ContactPage";
import { initialComments } from "./data/blogData";
import { useTheme } from "./context/ThemeContext";
import "./App.css";

function App() {
  const [comments, setComments] = useState(initialComments);
  const { theme } = useTheme();

  function handleAddComment(postId, newComment) {
    setComments((previousComments) => ({
      ...previousComments,
      [postId]: [
        ...(previousComments[postId] || []),
        newComment,
      ],
    }));
  }

  return (
    <div className={`app ${theme}-theme`}>
      <Navbar />

      <Routes>
        <Route
          path="/"
          element={<BlogPostsPage />}
        />

        <Route
          path="/posts/:id"
          element={
            <IndividualPostPage
              comments={comments}
              onAddComment={handleAddComment}
            />
          }
        />

        <Route
          path="/contact"
          element={<ContactPage />}
        />
      </Routes>

      <footer className="footer">
        <p>&copy; 2026 My Blog. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;