import { Link } from "react-router";
import { blogPosts } from "../data/blogData";

function BlogPostsPage() {
  return (
    <main id="home" className="main-content">
      <h2 className="page-heading">Latest Blog Posts</h2>

      <div className="post-list">
        {blogPosts.map((post) => (
          <article className="blog-card" key={post.id}>
            <h2>{post.title}</h2>
            <p className="post-meta">
              <strong>Author:</strong> {post.author}
            </p>
            <p className="post-meta">
              <strong>Date:</strong> {post.date}
            </p>
            <p>{post.content.slice(0, 120)}...</p>
            <Link className="read-more" to={`/posts/${post.id}`}>
              Read Full Post →
            </Link>
          </article>
        ))}
      </div>
    </main>
  );
}

export default BlogPostsPage;