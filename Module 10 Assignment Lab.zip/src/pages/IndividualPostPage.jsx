import { Link, useParams } from "react-router";
import { blogPosts } from "../data/blogData";
import CommentForm from "../components/CommentForm";
import CommentList from "../components/CommentList";

function IndividualPostPage({ comments, onAddComment }) {
  const { id } = useParams();
  const post = blogPosts.find((item) => item.id === id);

  if (!post) {
    return (
      <main className="main-content">
        <h2>Post not found</h2>
        <Link to="/">Return to Home</Link>
      </main>
    );
  }

  return (
    <main className="main-content">
      <article className="blog-card">
        <h1>{post.title}</h1>
        <p className="post-meta">
          <strong>Author:</strong> {post.author}
        </p>
        <p className="post-meta">
          <strong>Date:</strong> {post.date}
        </p>
        <p className="full-content">{post.content}</p>

        <section className="comments-section">
          <h2>Comments</h2>
          <CommentForm
            onAddComment={(comment) => onAddComment(post.id, comment)}
          />
          <CommentList comments={comments[post.id] || []} />
        </section>
      </article>
    </main>
  );
}

export default IndividualPostPage;