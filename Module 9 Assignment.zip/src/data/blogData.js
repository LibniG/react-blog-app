export const blogPost = {
  title: "My First Blog Post",
  content:
    "I like turtles.",
  author: "Libni Garza",
  date: "October 17, 2026",
};

export const initialComments = [
  {
    id: 1,
    name: "Xavier",
    text: "How do I get my cat to lose weight?",
  },
  {
    id: 2,
    name: "Trinh",
    text: "Where should I buy dog food!",
  },
  {
    id: 3,
    name: "Mandy",
    text: "I need new cat toys!",
  },
];