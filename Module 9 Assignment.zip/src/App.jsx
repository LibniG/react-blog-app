import { useState } from "react";
import { blogPost, initialComments } from "./data/blogData";
import "./App.css";

function App() {
  const [comments, setComments] = useState(initialComments);
  const [newComment, setNewComment] = useState("");

  function handleSubmit(event) {
    event.preventDefault();

    if (!newComment.trim()) return;

    setComments((previousComments) => [
      ...previousComments,
      {
        id: Date.now(),
        name: "",
        text: newComment.trim(),
      },
    ]);

    setNewComment("");
  }

  return (
    <div className="app">
      <header className="header">
        <h1>My Blog</h1>

        <nav>
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <main id="home" className="main-content">
        <article className="blog-card">
          <h1>{blogPost.title}</h1>

          <p className="post-content">{blogPost.content}</p>

          <p className="post-meta">
            <strong>Author:</strong> {blogPost.author}
          </p>

          <p className="post-meta">
            <strong>Date:</strong> {blogPost.date}
          </p>

          <section className="comments-section">
            <h2>Comments</h2>

            <form onSubmit={handleSubmit}>
              <textarea
                placeholder="Add a comment"
                value={newComment}
                onChange={(event) =>
                  setNewComment(event.target.value)
                }
                aria-label="Add a comment"
                required
              />

              <button type="submit">Submit</button>
            </form>

            <h3>Existing Comments:</h3>

            <ul>
              {comments.map((comment) => (
                <li key={comment.id}>
                  {comment.name
                    ? `${comment.name}: ${comment.text}`
                    : comment.text}
                </li>
              ))}
            </ul>
          </section>
        </article>
      </main>

      <footer id="contact" className="footer">
        <p>&copy; 2026 My Blog</p>
      </footer>
    </div>
  );
}

export default App;